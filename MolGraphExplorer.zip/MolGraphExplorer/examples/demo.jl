include("../src/MolGraphExplorer.jl")
using .MolGraphExplorer

println("MolGraphExplorer Demo")
println("----------------------")
println("Available molecules:")
println(join(list_molecules(), ", "))

while true
    print("\nEnter molecule name (or q to quit): ")
    name = readline()
    if lowercase(strip(name)) in ["q", "quit", "exit"]
        println("Goodbye!")
        break
    end

    m = load_molecule(name)
    stats = summary_stats(m)

    println("\nSummary:")
    println("Number of atoms: ", stats.atoms)
    println("Number of bonds: ", stats.bonds)
    println("Atom degrees: ", stats.degrees)
    println("Connected components (fragments): ", stats.fragments)

    println("\nChoose an action:")
    println("1) BFS traversal from atom 1")
    println("2) DFS traversal from atom 1")
    println("3) Plot molecular graph")
    print("Your choice: ")
    choice = readline()

    if choice == "1"
        println("BFS order: ", bfs_order(m, 1))
    elseif choice == "2"
        println("DFS order: ", dfs_order(m, 1))
    elseif choice == "3"
        plot_molecule(m; title=name)
    else
        println("Invalid choice.")
    end
end