# visualize.jl
# Molecular graph visualization (robust, file-based)

using Graphs
using GraphPlot
using Compose
using Cairo
using Fontconfig

export plot_molecule

"""
Convert adjacency list to a Graphs.jl SimpleGraph.
"""
function molgraph_to_simplegraph(adj::Vector{Vector{Int}})
    n = length(adj)
    g = SimpleGraph(n)
    for i in 1:n
        for j in adj[i]
            if i < j
                Graphs.add_edge!(g, i, j)
            end
        end
    end
    return g
end

"""
Plot molecular graph and save to PNG.
"""
function plot_molecule(m::MolGraph; title::String="molecule")
    g = molgraph_to_simplegraph(m.adj)

    labels = atom_labels(m)
    colors = [
        lbl == "C" ? "lightblue" :
        lbl == "O" ? "red" :
        lbl == "H" ? "gray" :
        "lightgreen"
        for lbl in labels
    ]

    ctx = gplot(
        g,
        nodelabel = labels,
        nodefillc = colors
    )

    filename = "$(title)_graph.png"
    draw(PNG(filename, 800px, 800px), ctx)

    println("Graph saved as: ", filename)
end
