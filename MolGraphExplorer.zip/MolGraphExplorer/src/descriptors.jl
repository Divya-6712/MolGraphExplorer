# descriptors.jl
# Simple molecular graph descriptors

export atom_degrees, num_bonds, summary_stats

"""
Return the degree (number of neighbors) of each atom.
"""
function atom_degrees(m::MolGraph)
    return [length(successors(m, i)) for i in 1:num_atoms(m)]
end

"""
Return the number of bonds in the molecule.
(Graph is stored with edges in both directions.)
"""
function num_bonds(m::MolGraph)
    total = sum(length(successors(m, i)) for i in 1:num_atoms(m))
    return total ÷ 2
end

"""
Return a summary of basic molecular descriptors.
"""
function summary_stats(m::MolGraph)
    return (
        atoms = num_atoms(m),
        bonds = num_bonds(m),
        degrees = atom_degrees(m),
        fragments = length(connected_components(m))
    )
end
