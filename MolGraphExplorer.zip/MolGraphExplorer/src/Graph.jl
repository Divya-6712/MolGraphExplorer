const nbatchsze=100
const ebatchsze=400

mutable struct GraphConfig
    # Configure the graph storage
    nodes_num::Int
    edges_num::Int
    nodes_capacity::Int
    edges_capacity::Int
end

struct Graph
    # Graph data structure - nodes and edges storage
    nodes::Array{Int,1}
    edges::Array{Int,1}
    cfg::GraphConfig

    function Graph(cptc_nodes::Int=nbatchsze, cptc_edges::Int=ebatchsze)
        nodes=zeros(Int,cptc_nodes) # Last position in nodes refer to the last position in edge to read. It is not a node.
        edges=zeros(Int,cptc_edges)
        cfg=GraphConfig(0,0,cptc_nodes,cptc_edges)
        return new(nodes, edges, cfg)
    end
end

function LastNode(g::Graph)
    return g.cfg.nodes_num
end

function LastEdge(g::Graph)
    return g.cfg.edges_num
end

function inflate_nodes!(g::Graph)
    g.cfg.nodes_capacity = max(nbatchsze,g.cfg.nodes_capacity)
    resize!(g.nodes, g.cfg.nodes_capacity)
end

function inflate_edges!(g::Graph)
    g.cfg.edges_capacity = max(ebatchsze,g.cfg.edges_capacity * 2)
    resize!(g.edges, g.cfg.edges_capacity)
end

function add_node!(g::Graph)
    if g.cfg.nodes_num+2 > g.cfg.nodes_capacity # +2 because we need to store the stop entry as well
        inflate_nodes!(g)
    end
    g.cfg.nodes_num += 1
    # The new node points out of the edge array and the stop entry points to the same index so to prevent reading any value in the edge array
    g.nodes[g.cfg.nodes_num]=g.cfg.edges_num+1
    g.nodes[g.cfg.nodes_num+1]=g.cfg.edges_num+1
end

function delete_node!(g::Graph, n::Int)
    # Remove all edges to and from node n
    successors=get_successors(g, n)
    for s in successors
        delete_edge!(g, n, s)
    end
    predecessors=get_predecessors(g, n)
    for p in predecessors
        delete_edge!(g, p, n)
    end
    # Shift left all nodes after n
    for i=n+1:g.cfg.nodes_num+1
        g.nodes[i-1]=g.nodes[i]
    end
    g.cfg.nodes_num -= 1
end

function add_edge!(g::Graph, from_n::Int, to_n::Int)
# Add an edge from node from_n to node to_n
    if g.cfg.edges_num+1 > g.cfg.edges_capacity
        inflate_edges!(g)
    end
    g.cfg.edges_num += 1
    # New edge is adding a new successor to node from_n
    # Create the space for the new edge by shifting right all edges
    # after from_n and updating the references in nodes
    pos_s=g.nodes[from_n+1]
    for i=g.cfg.edges_num:-1:pos_s
        g.edges[i]=g.edges[i-1]
    end
    for i=from_n+1:g.cfg.nodes_num
        g.nodes[i] += 1
    end
    g.edges[pos_s]=to_n
end

function delete_edge!(g::Graph, from_n::Int, to_n::Int)
    # Find the edge position
    start_pos=g.nodes[from_n]
    end_pos=g.nodes[from_n+1]-1
    i = start_pos
    while true
        if g.edges[i] == to_n || i > end_pos
            break
        end
        i += 1
    end
    if i > end_pos
        return # Edge not found
    end
    edge_pos = i
    # Shift left all edges after edge_pos
    for i=edge_pos:g.cfg.edges_num-1
        g.edges[i]=g.edges[i+1]
    end
    g.cfg.edges_num -= 1
    # Update the references in nodes
    for i=from_n+1:g.cfg.nodes_num
        g.nodes[i] -= 1
    end
end

function get_successors(g::Graph, n::Int)
    start_pos=g.nodes[n]
    end_pos=g.nodes[n+1]-1
    return g.edges[start_pos:end_pos]
end

function get_predecessors(g::Graph, n::Int)
    preds=Int[]
    for from_n=1:LastNode(g)
        for s=g.edges[from_n]:g.nodes[from_n+1]-1
            if g.edges[s]==n
                push!(preds, from_n)
            end
        end
    end
    return preds
end

function print_graph(g::Graph, title::String="", filename::String="")
    stream = filename == "" ? stdout : open(filename, "w")
    try
        println(stream, "# $title")
        println(stream, "$(LastNode(g)),$(LastEdge(g)) #dimensions")
        println(stream, "#----------------------")
        for n=1:LastNode(g)
            println(stream, "$n : ", join(get_successors(g,n), ","))
        end
    finally
        if filename != ""
            close(stream)
        end
    end
end

function load_graph!(g::Graph, filename::String)
    open(filename, "r") do file
        line = readline(file)
        while startswith(line, "#")
            line = readline(file)
        end
        line = split(line, "#")[1]
        dims = split(strip(line), ",")
        nnodes = parse(Int, dims[1])
        nedges = parse(Int, dims[2])
        if nnodes+2 > g.cfg.nodes_capacity # +2 because we need to store the stop entry as well
            inflate_nodes!(g)
        end
        if nedges+1 > g.cfg.edges_capacity # +1 because edges are 1-based
            inflate_edges!(g)
        end
        g.cfg.nodes_num = nnodes
        g.cfg.edges_num = nedges
        for from_n=1:nnodes
            line = readline(file)
            while startswith(line, "#")
                line = readline(file)
            end
            line = split(line, "#")[1]
            parts = split(strip(line), ":")
            successors = split(strip(parts[2]), ",")
            for s in successors
                s = strip(s)
                if s != ""
                    to_n = parse(Int, s)
                    add_edge!(g, from_n, to_n)
                end
            end
        end
    end
end

function clear_graph!(g::Graph)
    g.cfg.nodes_num=0
    g.cfg.edges_num=0
end

function copy_graph(g::Graph)
    new_g=Graph(g.cfg.nodes_capacity, g.cfg.edges_capacity)
    new_g.cfg.nodes_num=g.cfg.nodes_num
    new_g.cfg.edges_num=g.cfg.edges_num
    for i=1:g.cfg.nodes_num+1
        new_g.nodes[i]=g.nodes[i]
    end
    for i=1:g.cfg.edges_num
        new_g.edges[i]=g.edges[i]
    end
    return new_g
end