# dataset.jl
# Small curated molecular dataset for chemoinformatics examples

export list_molecules, load_molecule

"""
Return the list of available molecule names.
"""
function list_molecules()
    return ["methane", "ethane", "ethanol", "benzene"]
end

"""
Construct and return a MolGraph corresponding to the given molecule name.
"""
function load_molecule(name::String)
    name = lowercase(strip(name))
    m = MolGraph()

    if name == "methane"
        # CH4
        c = add_atom!(m, :C)
        for _ in 1:4
            h = add_atom!(m, :H)
            add_bond!(m, c, h)
        end

    elseif name == "ethane"
        # C2H6
        c1 = add_atom!(m, :C)
        c2 = add_atom!(m, :C)
        add_bond!(m, c1, c2)
        for _ in 1:3
            add_bond!(m, c1, add_atom!(m, :H))
            add_bond!(m, c2, add_atom!(m, :H))
        end

    elseif name == "ethanol"
        # C-C-O (hydrogens omitted for simplicity)
        c1 = add_atom!(m, :C)
        c2 = add_atom!(m, :C)
        o  = add_atom!(m, :O)
        add_bond!(m, c1, c2)
        add_bond!(m, c2, o)

    elseif name == "benzene"
        # Six-carbon ring (aromatic simplified)
        atoms = [add_atom!(m, :C) for _ in 1:6]
        for i in 1:5
            add_bond!(m, atoms[i], atoms[i+1])
        end
        add_bond!(m, atoms[6], atoms[1])

    else
        error("Unknown molecule name: $name")
    end

    return m
end