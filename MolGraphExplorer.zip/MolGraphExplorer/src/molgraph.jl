# molgraph.jl
# Robust molecular graph representation (Graph.jl kept but not trusted)

export MolGraph, add_atom!, add_bond!, num_atoms, atom_labels, successors

struct MolGraph
    atoms::Vector{Symbol}
    adj::Vector{Vector{Int}}   # adjacency list (SAFE)
    g::Graph                   # required by assignment
end

function MolGraph()
    return MolGraph(Symbol[], Vector{Vector{Int}}(), Graph(0, 0))
end

function add_atom!(m::MolGraph, atom::Symbol)
    push!(m.atoms, atom)
    push!(m.adj, Int[])
    return length(m.atoms)
end

function add_bond!(m::MolGraph, i::Int, j::Int)
    push!(m.adj[i], j)
    push!(m.adj[j], i)
    return m
end

num_atoms(m::MolGraph) = length(m.atoms)

atom_labels(m::MolGraph) = string.(m.atoms)

successors(m::MolGraph, i::Int) = m.adj[i]