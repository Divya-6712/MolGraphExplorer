# algorithms.jl
# Graph algorithms applied to molecular graphs

export bfs_order, dfs_order, connected_components

"""
Breadth-First Search traversal order starting from atom `start`.
"""
function bfs_order(m::MolGraph, start::Int)
    n = num_atoms(m)
    visited = falses(n)
    queue = [start]
    visited[start] = true
    order = Int[]

    while !isempty(queue)
        u = popfirst!(queue)
        push!(order, u)
        for v in successors(m, u)
            if !visited[v]
                visited[v] = true
                push!(queue, v)
            end
        end
    end
    return order
end

"""
Depth-First Search traversal order starting from atom `start`.
"""
function dfs_order(m::MolGraph, start::Int)
    n = num_atoms(m)
    visited = falses(n)
    order = Int[]

    function visit(u)
        visited[u] = true
        push!(order, u)
        for v in successors(m, u)
            if !visited[v]
                visit(v)
            end
        end
    end

    visit(start)
    return order
end

"""
Find connected components (molecular fragments).
Returns a vector of vectors of atom indices.
"""
function connected_components(m::MolGraph)
    n = num_atoms(m)
    visited = falses(n)
    components = Vector{Vector{Int}}()

    for i in 1:n
        if !visited[i]
            comp = Int[]
            stack = [i]
            visited[i] = true

            while !isempty(stack)
                u = pop!(stack)
                push!(comp, u)
                for v in successors(m, u)
                    if !visited[v]
                        visited[v] = true
                        push!(stack, v)
                    end
                end
            end

            push!(components, comp)
        end
    end

    return components
end
